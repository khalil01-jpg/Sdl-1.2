#include "game_background.h"
#include <time.h>

void setup_game_background(GameBackground* gb) {
    gb->camera_a.x = 0;
    gb->camera_a.y = 0;
    gb->camera_a.w = SCREEN_WIDTH;
    gb->camera_a.h = SCREEN_HEIGHT;

    gb->camera_b.x = 0;
    gb->camera_b.y = 0;
    gb->camera_b.w = SCREEN_WIDTH / 2;
    gb->camera_b.h = SCREEN_HEIGHT;

    gb->screen_pos_a.x = SCREEN_WIDTH / 2;
    gb->screen_pos_a.y = 0;
    gb->screen_pos_a.w = SCREEN_WIDTH / 2;
    gb->screen_pos_a.h = SCREEN_HEIGHT;

    gb->screen_pos_b.x = 0;
    gb->screen_pos_b.y = 0;
    gb->screen_pos_b.w = SCREEN_WIDTH / 2;
    gb->screen_pos_b.h = SCREEN_HEIGHT;

    gb->scroll_velocity_x = SCROLL_SPEED_X;
    gb->scroll_velocity_y = SCROLL_SPEED_Y;
    gb->split_screen_mode = 0;

    gb->guide_overlay = IMG_Load("assets/guidewindow.png");
    if (!gb->guide_overlay) {
        printf("Failed to load guidewindow.png: %s\n", IMG_GetError());
    }

    gb->display_guide = 0;
}

void release_background_resources(GameBackground* gb) {
    if (gb->background_image != NULL) {
        SDL_FreeSurface(gb->background_image);
        gb->background_image = NULL;
    }
    if (gb->guide_overlay != NULL) {
        SDL_FreeSurface(gb->guide_overlay);
        gb->guide_overlay = NULL;
    }
}

void draw_background(SDL_Surface* screen, GameBackground* gb) {
    if (gb->split_screen_mode) {
        SDL_BlitSurface(gb->background_image, &gb->camera_b, screen, &gb->screen_pos_b);
        SDL_BlitSurface(gb->background_image, &gb->camera_a, screen, &gb->screen_pos_a);
    } else {
        SDL_BlitSurface(gb->background_image, &gb->camera_a, screen, NULL);
    }
}

void scroll_right_player_one(GameBackground* gb) {
    gb->camera_a.x += gb->scroll_velocity_x;
    if (gb->camera_a.x > gb->background_image->w - gb->camera_a.w) {
        gb->camera_a.x = gb->background_image->w - gb->camera_a.w;
    }
}

void scroll_left_player_one(GameBackground* gb) {
    gb->camera_a.x -= gb->scroll_velocity_x;
    if (gb->camera_a.x < 0) {
        gb->camera_a.x = 0;
    }
}

void scroll_up_player_one(GameBackground* gb) {
    gb->camera_a.y -= gb->scroll_velocity_y;
    if (gb->camera_a.y < 0) {
        gb->camera_a.y = 0;
    }
}

void scroll_down_player_one(GameBackground* gb) {
    gb->camera_a.y += gb->scroll_velocity_y;
    if (gb->camera_a.y > gb->background_image->h - gb->camera_a.h) {
        gb->camera_a.y = gb->background_image->h - gb->camera_a.h;
    }
}

void scroll_right_player_two(GameBackground* gb) {
    gb->camera_b.x += gb->scroll_velocity_x;
    if (gb->camera_b.x > gb->background_image->w - gb->camera_b.w) {
        gb->camera_b.x = gb->background_image->w - gb->camera_b.w;
    }
}

void scroll_left_player_two(GameBackground* gb) {
    gb->camera_b.x -= gb->scroll_velocity_x;
    if (gb->camera_b.x < 0) {
        gb->camera_b.x = 0;
    }
}

void scroll_up_player_two(GameBackground* gb) {
    gb->camera_b.y -= gb->scroll_velocity_y;
    if (gb->camera_b.y < 0) {
        gb->camera_b.y = 0;
    }
}

void scroll_down_player_two(GameBackground* gb) {
    gb->camera_b.y += gb->scroll_velocity_y;
    if (gb->camera_b.y > gb->background_image->h - gb->camera_b.h) {
        gb->camera_b.y = gb->background_image->h - gb->camera_b.h;
    }
}

void start_timer(GameTimer* gt) {
    gt->start_tick = time(NULL);
    gt->elapsed_seconds = 0;
}

void update_timer(GameTimer* gt) {
    time_t current_tick = time(NULL);
    gt->elapsed_seconds = (int)(current_tick - gt->start_tick);
}

void draw_timer(SDL_Surface* screen, GameTimer* gt, TTF_Font* font, SDL_Color text_color) {
    char timer_text[50];
    sprintf(timer_text, "Time: %d seconds", gt->elapsed_seconds);

    SDL_Surface* text_surface = TTF_RenderText_Solid(font, timer_text, text_color);
    if (text_surface != NULL) {
        SDL_Rect text_position = {10, 10};
        SDL_BlitSurface(text_surface, NULL, screen, &text_position);
        SDL_FreeSurface(text_surface);
    }
}

void draw_guide_window(SDL_Surface* screen, GameBackground* gb) {
    if (gb->display_guide && gb->guide_overlay != NULL) {
        SDL_Rect guide_position = {SCREEN_WIDTH - 410, 10};
        SDL_BlitSurface(gb->guide_overlay, NULL, screen, &guide_position);
    }
}
