#ifndef GAME_BACKGROUND_H
#define GAME_BACKGROUND_H

#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_ttf.h>

#define SCREEN_WIDTH  1700
#define SCREEN_HEIGHT 900
#define SCROLL_SPEED_X 5
#define SCROLL_SPEED_Y 5

typedef struct {
    SDL_Surface* background_image;
    SDL_Rect camera_a;
    SDL_Rect camera_b;
    SDL_Rect screen_pos_a;
    SDL_Rect screen_pos_b;
    int scroll_velocity_x;
    int scroll_velocity_y;
    int split_screen_mode;
    SDL_Surface* guide_overlay;
    int display_guide;
} GameBackground;

typedef struct {
    time_t start_tick;
    int elapsed_seconds;
} GameTimer;

void setup_game_background(GameBackground* gb);
void release_background_resources(GameBackground* gb);
void draw_background(SDL_Surface* screen, GameBackground* gb);
void scroll_right_player_one(GameBackground* gb);
void scroll_left_player_one(GameBackground* gb);
void scroll_up_player_one(GameBackground* gb);
void scroll_down_player_one(GameBackground* gb);
void scroll_right_player_two(GameBackground* gb);
void scroll_left_player_two(GameBackground* gb);
void scroll_up_player_two(GameBackground* gb);
void scroll_down_player_two(GameBackground* gb);
void start_timer(GameTimer* gt);
void update_timer(GameTimer* gt);
void draw_timer(SDL_Surface* screen, GameTimer* gt, TTF_Font* font, SDL_Color text_color);
void draw_guide_window(SDL_Surface* screen, GameBackground* gb);

#endif
