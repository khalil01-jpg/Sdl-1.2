#include "game_background.h"
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_ttf.h>
#include <stdio.h>

#define DISPLAY_WIDTH  1700
#define DISPLAY_HEIGHT 900

int main(int argc, char* argv[]) {

    if (SDL_Init(SDL_INIT_VIDEO) < 0) {
        printf("Error initializing SDL: %s\n", SDL_GetError());
        return -1;
    }
    if (TTF_Init() < 0) {
        printf("Error initializing SDL_ttf: %s\n", TTF_GetError());
        SDL_Quit();
        return -1;
    }

    SDL_Surface* display = SDL_SetVideoMode(DISPLAY_WIDTH, DISPLAY_HEIGHT, 32, SDL_HWSURFACE);
    if (!display) {
        printf("Error creating display surface: %s\n", SDL_GetError());
        TTF_Quit();
        SDL_Quit();
        return -1;
    }

    TTF_Font* font = TTF_OpenFont("assets/arial.ttf", 24);
    if (!font) {
        printf("Error loading font: %s\n", TTF_GetError());
        SDL_FreeSurface(display);
        TTF_Quit();
        SDL_Quit();
        return -1;
    }

    GameBackground gb;
    gb.background_image = IMG_Load("assets/maptry.png");
    if (!gb.background_image) {
        printf("Error loading background image: %s\n", IMG_GetError());
        TTF_CloseFont(font);
        SDL_FreeSurface(display);
        TTF_Quit();
        SDL_Quit();
        return -1;
    }
    setup_game_background(&gb);
    GameTimer gt;
    start_timer(&gt);
    SDL_Color textColor = {255, 255, 255};

    int is_running = 1;
    SDL_Event event;
    Uint8* keystate = NULL;

    while (is_running) {
 
        while (SDL_PollEvent(&event)) {
            if (event.type == SDL_QUIT) {
                is_running = 0;
            }
        }

        keystate = SDL_GetKeyState(NULL);
        if (keystate[SDLK_h]) {
            gb.split_screen_mode = !gb.split_screen_mode;
            SDL_Delay(200);
        }
        if (keystate[SDLK_i]) {
            gb.display_guide = !gb.display_guide;
            SDL_Delay(200);
        }
        if (keystate[SDLK_RIGHT]) scroll_right_player_one(&gb);
        if (keystate[SDLK_LEFT]) scroll_left_player_one(&gb);
        if (keystate[SDLK_UP]) scroll_up_player_one(&gb);
        if (keystate[SDLK_DOWN]) scroll_down_player_one(&gb);
        if (gb.split_screen_mode) {
            if (keystate[SDLK_d]) scroll_right_player_two(&gb);
            if (keystate[SDLK_q]) scroll_left_player_two(&gb);
            if (keystate[SDLK_z]) scroll_up_player_two(&gb);
            if (keystate[SDLK_s]) scroll_down_player_two(&gb);
        }
        update_timer(&gt);

        draw_background(display, &gb);
        draw_timer(display, &gt, font, textColor);
        draw_guide_window(display, &gb);
        SDL_Flip(display);
    }
    release_background_resources(&gb);
    TTF_CloseFont(font);
    SDL_FreeSurface(display);
    TTF_Quit();
    SDL_Quit();

    return 0;
}
